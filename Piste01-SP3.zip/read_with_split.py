import serial
import mysql.connector
import datetime
import time
con = mysql.connector.connect(host = "ec2-52-211-35-84.eu-west-1.compute.amazonaws.com" ,user="piste",password ="07959906"
	                                                                                    ,database = "piste",port = 3306)
con.autocommit = True
cursor = con.cursor()
print ("connecte")
ser = serial.Serial('/dev/ttyUSB0' , 115200)

while True :
	data = ser.readline()

	if data:
		  
	      x = data.decode("utf-8").split(":")
	      idz = x[0]
	      hum = round((1-(float(x[1])/4091))*100 ,4)
	      lum = 4096-float(x[2])
	      tmp = x[3]
	      
	      
	      now = datetime.datetime.now()
	      print(x[0])
	      print(hum)
	      print(lum)
	      print(x[3])
	      cursor.execute("INSERT INTO piste.aws (sensors_data_id,sensors_luminosity_data,sensors_humidity_data,sensors_temperature_data,)sensors_data_time,sensors_data_date) VALUES(%s,%s,%s,%s,%s,%s)" ,(idz,lum,hum,tmp,time.strftime(r"%H:%M:%S", time.localtime()),time.strftime(r"%Y-%m-%d", time.localtime())))	
	      	

print ("c bon ")
cursor.close()
con.close()

