function localFilename(url)
{
	var x = url.lastIndexOf("/");
	url = url.slice(x + 1);
	return url;		
}
 
 
function changeImage(element)
{ 
	var v = element.getAttribute("src");
	v = localFilename(v);
 
	if(v == "./Images/robot.jpg")
		v = "./Images/images.jpg";
	else
		v = "./Images/robot.jpg";
 
	element.setAttribute("src", v);	
 
}
 
function changeBackground()
{
	var z = new Image();
	z.src = "./Images/images.jpg";
	document.body.background=z.src;
}